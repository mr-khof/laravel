<footer class="col-12 bg-secondary p-4 small text-center text-white">
    <p class="small mb-0">تمامی حقوق سایت محفوظ است. کپی رایت ۱۴۰۰</p>
</footer>
<?php /**PATH C:\laravel\laravel-proj\resources\views/layouts/footer.blade.php ENDPATH**/ ?>