<section class="card-body shadow-lg rounded rounded-3">
    <header>
        <h1 class="h6 text-primary">پر بازدیدترین ها</h1>
    </header>
</section>
<?php /**PATH C:\laravel\laravel-proj\resources\views/layouts/side.blade.php ENDPATH**/ ?>