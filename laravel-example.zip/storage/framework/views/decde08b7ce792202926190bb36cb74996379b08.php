<section class="card-body shadow-lg rounded rounded-3">
    <header>
        <h1 class="h6 text-primary">تبلیغات</h1>
    </header>
</section>
<?php /**PATH C:\laravel\laravel-proj\resources\views/layouts/mod.blade.php ENDPATH**/ ?>