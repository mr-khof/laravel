<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="/">آموزش برنامه نویسی</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">صفحه اصلی</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/blog">بلاگ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/about-us">درباره ما</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/contact-us">تماس با ما</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/login">ورود کاربر</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/register">ثبت نام کاربر</a>
                </li>

            </ul>
            <form class="d-flex">
                <input class="form-control me-2" type="search" placeholder="کلمه مورد نظر را تایپ کنید" aria-label="Search">
                <button class="btn btn-outline-light" type="submit">جستجو</button>
            </form>
        </div>
    </div>
</nav>
<?php /**PATH C:\laravel\laravel-proj\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>