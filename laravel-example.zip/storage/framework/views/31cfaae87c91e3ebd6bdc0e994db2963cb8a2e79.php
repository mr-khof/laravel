<?php $__env->startSection('title','تماس با ما'); ?>

<?php $__env->startSection('content'); ?>
    <header>
        <h1 class="h-6 text-primary">راه های ارتباطی</h1>
    </header>
    <section class="p-1">
        <p class="h-6">تلفن تماس: &ndash; 09357175301</p>
        <p class="h-6">آدرس:&ndash; خراسان رضوی, مشهد, بلوار وکیل آباد, وکیل آباد 73, خیابان دندانپزشکان, نبش دنداپزشکان 12, پلاک 30, واحد 4 </p>
        <iframe class="w-100 h-auto shadow-sm border-0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3193226.9263130943!2d-98.81915774627947!3d38.59399254426069!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited%20States!5e0!3m2!1sen!2s!4v1645361545058!5m2!1sen!2s" allowfullscreen="" loading="lazy"></iframe>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.laravel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\laravel-proj\resources\views/contact.blade.php ENDPATH**/ ?>