<?php $__env->startSection('title','درباره ما'); ?>

<?php $__env->startSection('content'); ?>
    <header>
        <h1 class="h6 text-primary">درباره ما</h1>
    </header>
    <section class="p-1">
        <p>
            هدف اصلی ما اموزش عالی و ارائه بهترین و با کیفیت ترین اموزش های برنامه نویسی از جمله (php,javascript,css,html,c,++C) برای تمامی علاقه مندان عزیز و دانشجویان گرامی که به رشته مهندسی کامپیوتر و برنامه نویسی گرایش دارند بهترین هارو درنظر گرفته است.
        </p>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.laravel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\laravel-proj\resources\views/about-us.blade.php ENDPATH**/ ?>