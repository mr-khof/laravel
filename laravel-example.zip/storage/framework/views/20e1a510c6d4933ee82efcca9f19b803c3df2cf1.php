<!DOCTYPE html>
<html lang="fa-en" dir="rtl">
<head>
    <meta charset="UTF-8"/>
    <meta name="description" content="Free Web tutorials"/>
    <meta name="keywords" content="HTML, CSS, JavaScript"/>
    <meta name="author" content="mr.khof"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>آموزش برنامه نویسی | <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" href="/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="/css/app.css"/>
</head>
<body>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container-fluid">
    <section class="row my-4">

        <article class="col-12 col-sm-12 col-md-12 col-lg-7 col-xl-8 col-xxl-9">

            <article class="card-body shadow-lg rounded rounded-3">
                <?php echo $__env->yieldContent('content'); ?>
            </article>

        </article>
        <aside class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-2 col-xxl-2">
         <?php echo $__env->make('layouts.side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php echo $__env->yieldContent('data'); ?>
        </aside>
        <section class="col-12 col-sm-12 col-md-6 col-lg-2 col-xl-2 col-xxl-1">
          <?php echo $__env->make('layouts.mod', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>





    </section>
</main>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<script src="/js/app.js"></script>
</body>
</html>
<?php /**PATH C:\laravel\laravel-proj\resources\views/layouts/laravel.blade.php ENDPATH**/ ?>