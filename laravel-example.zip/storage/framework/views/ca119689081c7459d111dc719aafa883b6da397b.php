<?php $__env->startSection('title','لیست مقالات'); ?>
<?php $__env->startSection('content'); ?>
    <header>
        <h1 class="h-6 text-primary">لیست مقالات ارائه شده</h1>
    </header>
    <section class="p-1">
        <p>آموزش زبان های کاربردی برنامه نویسی</p>
        <p>در وبسایت قصد داریم, بهینه ترین و مهم ترین و کاربردی ترین زبان های برنامه نویسی دنیا که در دنیای امروز طرفداران بسیار زیادی پیدا کرده و همچنین بازار کار بسیار عالی دارند را به شما اموزش دهیم. با این اموزش ها میتوانید در انتهای دوره با تمرین و پشتکار فراوان به یک برنامه نویس خوب و حرفه ای تبدیل شوید. اموزشات بصورت رایگان در دسترس قرار میگیرند و در سایت قرار داده میشوند. همچنین در قسمت مقالات میتوانید ایرادات, خطاها, حل مشکلات و نمونه کار خود را قرار دهید.</p>
        <p class="text-primary">&napprox;دوستار شما mr.khof&napprox;</p>
    </section>
    <?php if(empty($articles)): ?>
        <br> هیچ مقاله ای وجود ندارد
    <?php endif; ?>
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <br> <?php echo e($article); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.laravel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\laravel-proj\resources\views/blog.blade.php ENDPATH**/ ?>