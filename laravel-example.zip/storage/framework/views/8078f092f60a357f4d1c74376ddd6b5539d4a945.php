<header class="p-4">
    <a href="/" class="text-decoration-none text-primary">
        <h1 class="h3 text-primary">آموزش برنامه نویسی</h1>
    </a>
</header>
<?php /**PATH C:\laravel\laravel-proj\resources\views/layouts/header.blade.php ENDPATH**/ ?>