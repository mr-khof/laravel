@extends('layouts.laravel')
@section('title','درباره ما')

@section('content')
    <header>
        <h1 class="h6 text-primary">درباره ما</h1>
    </header>
    <section class="p-1">
        <p>
            هدف اصلی ما اموزش عالی و ارائه بهترین و با کیفیت ترین اموزش های برنامه نویسی از جمله (php,javascript,css,html,c,++C) برای تمامی علاقه مندان عزیز و دانشجویان گرامی که به رشته مهندسی کامپیوتر و برنامه نویسی گرایش دارند بهترین هارو درنظر گرفته است.
        </p>
    </section>

@endsection
