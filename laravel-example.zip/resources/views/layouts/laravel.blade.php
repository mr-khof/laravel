<!DOCTYPE html>
<html lang="fa-en" dir="rtl">
<head>
    <meta charset="UTF-8"/>
    <meta name="description" content="Free Web tutorials"/>
    <meta name="keywords" content="HTML, CSS, JavaScript"/>
    <meta name="author" content="mr.khof"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>آموزش برنامه نویسی | @yield('title')</title>
    <link rel="icon" href="/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="/css/app.css"/>
</head>
<body>
@include('layouts.header')

@include('layouts.navbar')

<main class="container-fluid">
    <section class="row my-4">

        <article class="col-12 col-sm-12 col-md-12 col-lg-7 col-xl-8 col-xxl-9">

            <article class="card-body shadow-lg rounded rounded-3">
                @yield('content')
            </article>

        </article>
        <aside class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-2 col-xxl-2">
         @include('layouts.side')
         @yield('data')
        </aside>
        <section class="col-12 col-sm-12 col-md-6 col-lg-2 col-xl-2 col-xxl-1">
          @include('layouts.mod')
        </section>





    </section>
</main>
@include('layouts.footer')




<script src="/js/app.js"></script>
</body>
</html>
